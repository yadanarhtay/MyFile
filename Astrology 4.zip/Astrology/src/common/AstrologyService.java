package common;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface AstrologyService extends Remote {

    String getPrediction(String zodiac, String type, int pile) throws RemoteException;

    String getLuckyColor(String zodiac) throws RemoteException;

    int getLuckyNumber(String zodiac) throws RemoteException;

    String getPreview(String zodiac, String type, String timeframe) throws RemoteException;

    // ✅ Add Myanmar & Chinese methods
    String getMyanmarPrediction(String myanmarDob) throws RemoteException;

    String getChineseZodiac(int year) throws RemoteException;
}