package client;

import ui.BackgroundPanel;
import ui.RoundedPanel;
import ui.StyledButton;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

public class ClientGUI extends JFrame {

    private CardLayout cardLayout = new CardLayout();
    private JPanel mainPanel = new JPanel(cardLayout);

    // Page 1
    private JTextField dobField, zodiacField;
    private JComboBox<String> typeBox, timeframeBox;
    private JTextArea previewArea;
    private JLabel zodiacEmoji, luckyColor, luckyNumber;

    // Page 2
    private JButton p1, p2, p3;
    private JTextArea pileArea;
    private int selectedPile = 0;
    private JLabel page2Zodiac, page2Emoji;

    // Page 3
    private JTextField yearField;
    private JTextArea chineseArea;
    private JLabel chineseZodiacLabel;

    private Map<String, String> zodiacEmojis = new HashMap<>();
    private Map<String, String> chineseEmojis = new HashMap<>();
    private Map<String, String[]> predictionMap = new HashMap<>();

    public ClientGUI() {
        initZodiacEmojis();
        initChineseEmojis();
        initPredictions();

        setTitle("Astrology Prediction System");
        setSize(850, 800);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        BufferedImage bg;
        try {
            bg = ImageIO.read(getClass().getClassLoader().getResource("image/bg.jpg"));
        } catch (Exception e) {
            bg = new BufferedImage(900, 700, BufferedImage.TYPE_INT_ARGB);
        }
        setContentPane(new BackgroundPanel(bg));

        mainPanel.setOpaque(false);
        mainPanel.add(page1(), "page1");
        mainPanel.add(page2(), "page2");
        mainPanel.add(page3(), "page3");

        add(mainPanel);
        setVisible(true);
    }

    // ================= Page 1 =================
    private JPanel page1() {
        RoundedPanel card = new RoundedPanel(new Color(255, 255, 255, 180));
        card.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(6, 6, 6, 6);
        c.fill = GridBagConstraints.HORIZONTAL;

        JLabel title = new JLabel("🌟 Astrology Prediction 🔮", JLabel.CENTER);
        title.setFont(new Font("Serif", Font.BOLD, 24));
        c.gridx = 0; c.gridy = 0; c.gridwidth = 2;
        card.add(title, c);

        c.gridwidth = 1; c.gridy++;
        card.add(new JLabel("DOB (YYYY-MM-DD)"), c);
        dobField = new JTextField(); c.gridx = 1; card.add(dobField, c);

        c.gridx = 0; c.gridy++;
        card.add(new JLabel("Zodiac"), c);
        zodiacField = new JTextField(); zodiacField.setEditable(false);
        c.gridx = 1; card.add(zodiacField, c);

        c.gridx = 0; c.gridy++;
        card.add(new JLabel("Zodiac Emoji"), c);
        zodiacEmoji = new JLabel("", JLabel.CENTER);
        zodiacEmoji.setFont(new Font("SansSerif", Font.PLAIN, 28));
        c.gridx = 1; card.add(zodiacEmoji, c);

        c.gridx = 0; c.gridy++;
        card.add(new JLabel("Time Frame"), c);
        timeframeBox = new JComboBox<>(new String[]{"Daily","Weekly","Monthly"});
        c.gridx = 1; card.add(timeframeBox, c);

        c.gridx = 0; c.gridy++;
        card.add(new JLabel("Prediction Type"), c);
        typeBox = new JComboBox<>(new String[]{"Love","Career","Health","Fortune","Education"});
        c.gridx = 1; card.add(typeBox, c);

        c.gridx = 0; c.gridy++;
        card.add(new JLabel("Lucky Color 🎨"), c);
        luckyColor = new JLabel("-"); c.gridx = 1; card.add(luckyColor, c);

        c.gridx = 0; c.gridy++;
        card.add(new JLabel("Lucky Number 🔢"), c);
        luckyNumber = new JLabel("-"); c.gridx = 1; card.add(luckyNumber, c);

        c.gridx = 0; c.gridy++; c.gridwidth = 2;
        previewArea = new JTextArea(12,50);
        previewArea.setOpaque(false); previewArea.setEditable(false);
        previewArea.setLineWrap(true); previewArea.setWrapStyleWord(true);
        card.add(previewArea, c);

        c.gridy++;
        JPanel btnPanel = new JPanel(); btnPanel.setOpaque(false);
        StyledButton predict = new StyledButton("Predict");
        StyledButton pickPile = new StyledButton("Pick a Pile");
        StyledButton chinese = new StyledButton("Chinese Zodiac");
        StyledButton clear = new StyledButton("Clear");

        predict.addActionListener(e -> preview());
        pickPile.addActionListener(e -> cardLayout.show(mainPanel,"page2"));
        chinese.addActionListener(e -> cardLayout.show(mainPanel,"page3"));
        clear.addActionListener(e -> clearPage1());

        btnPanel.add(predict); btnPanel.add(pickPile); btnPanel.add(chinese); btnPanel.add(clear);
        c.gridwidth = 2; card.add(btnPanel, c);

        JPanel wrap = new JPanel(); wrap.setOpaque(false); wrap.add(card);
        return wrap;
    }

    // ================= Page 2 =================
    private JPanel page2() {
        RoundedPanel card = new RoundedPanel(new Color(255,255,255,180));
        card.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints(); c.insets = new Insets(8,8,8,8);

        JLabel title = new JLabel("🔮 Pick a Pile 🔮", JLabel.CENTER);
        title.setFont(new Font("Serif",Font.BOLD,24));
        c.gridx=0;c.gridy=0;c.gridwidth=3; card.add(title,c);

        c.gridy++;
        page2Zodiac = new JLabel(""); page2Emoji = new JLabel("",JLabel.CENTER);
        card.add(page2Zodiac,c); c.gridx=1; card.add(page2Emoji,c);

        c.gridy++;
        JPanel piles = new JPanel(); piles.setOpaque(false);
        p1 = pileBtn("image/p1.jpg",1);
        p2 = pileBtn("image/p2.jpg",2);
        p3 = pileBtn("image/p3.jpg",3);
        piles.add(p1); piles.add(p2); piles.add(p3);
        card.add(piles,c);

        c.gridy++;
        pileArea = new JTextArea(6,45); pileArea.setOpaque(false); pileArea.setEditable(false); pileArea.setLineWrap(true);
        card.add(pileArea,c);

        c.gridy++;
        JPanel btnPanel = new JPanel(); btnPanel.setOpaque(false);
        StyledButton predict = new StyledButton("Predict");
        StyledButton clear = new StyledButton("Clear");
        StyledButton back = new StyledButton("Back");
        predict.addActionListener(e -> pilePredict());
        clear.addActionListener(e -> clearPile());
        back.addActionListener(e -> cardLayout.show(mainPanel,"page1"));
        btnPanel.add(predict); btnPanel.add(clear); btnPanel.add(back);
        card.add(btnPanel,c);

        JPanel wrap = new JPanel(); wrap.setOpaque(false); wrap.add(card); return wrap;
    }

    // ================= Page 3 =================
    private JPanel page3() {
        RoundedPanel card = new RoundedPanel(new Color(255,255,255,180));
        card.setLayout(new GridBagLayout()); GridBagConstraints c = new GridBagConstraints(); c.insets = new Insets(8,8,8,8);
        c.fill = GridBagConstraints.HORIZONTAL;

        JLabel title = new JLabel("🐉 Chinese Zodiac Prediction 🐲",JLabel.CENTER);
        title.setFont(new Font("Serif",Font.BOLD,22));
        c.gridx=0;c.gridy=0;c.gridwidth=2; card.add(title,c);

        c.gridwidth=1;c.gridy++;
        card.add(new JLabel("Enter Year of Birth:"),c);
        yearField = new JTextField(); c.gridx=1; card.add(yearField,c);

        c.gridx=0;c.gridy++;
        card.add(new JLabel("Zodiac Animal:"),c);
        chineseZodiacLabel = new JLabel("",JLabel.CENTER); chineseZodiacLabel.setFont(new Font("SansSerif",Font.PLAIN,24));
        c.gridx=1; card.add(chineseZodiacLabel,c);

        c.gridx=0;c.gridy++;c.gridwidth=2;
        chineseArea = new JTextArea(10,40); chineseArea.setOpaque(false); chineseArea.setEditable(false); chineseArea.setLineWrap(true); chineseArea.setWrapStyleWord(true);
        card.add(chineseArea,c);

        c.gridy++;
        JPanel btnPanel = new JPanel(); btnPanel.setOpaque(false);
        StyledButton predict = new StyledButton("Predict");
        StyledButton clear = new StyledButton("Clear");
        StyledButton back = new StyledButton("Back");
        predict.addActionListener(e -> predictChinese());
        clear.addActionListener(e -> clearChinese());
        back.addActionListener(e -> cardLayout.show(mainPanel,"page1"));
        btnPanel.add(predict); btnPanel.add(clear); btnPanel.add(back);
        card.add(btnPanel,c);

        JPanel wrap = new JPanel(); wrap.setOpaque(false); wrap.add(card); return wrap;
    }

    // ================= Page1 Logic =================
    private void preview() {
        try {
            LocalDate d = LocalDate.parse(dobField.getText());
            String zodiac = zodiac(d.getMonthValue(), d.getDayOfMonth());
            zodiacField.setText(zodiac);
            zodiacEmoji.setText(zodiacEmojis.get(zodiac));
            page2Zodiac.setText("Zodiac: " + zodiac);
            page2Emoji.setText(zodiacEmojis.get(zodiac));

            // Random prediction
            String type = typeBox.getSelectedItem().toString();
            String[] predictions = predictionMap.get(type);
            if(predictions!=null && predictions.length>0){
                int idx = (int)(Math.random()*predictions.length);
                previewArea.setText(predictions[idx]);
            } else {
                previewArea.setText("No prediction available.");
            }

            luckyColor.setText(getLuckyColor(zodiac));
            luckyNumber.setText(getLuckyNumber(zodiac));

        } catch(Exception e){
            previewArea.setText("Invalid DOB format. Use YYYY-MM-DD.");
        }
    }

    private void pilePredict() {
        if(selectedPile==0){ JOptionPane.showMessageDialog(this,"Select a pile first"); return; }
        String[] pilePredictions = {
            "🦋Pile-1🦋\r\n"
            + "လက်ရှိလုပ်နေတဲ့အလုပ်အပြင်နောက်တစ်ခုထပ်လုပ်ဖို့ကိုစဉ်းစားနေတာမျိုးအစီစဉ်ချနေတာမျိုးရှိမယ် ၊ရွေးချယ်စရာ၂မျိုးကြုံမယ်၊အခွင့်ရေးသစ်တွေအလားလာကောင်းတွေရရှိမယ်၊ငွေဝင်နေသလိုတစ်ဖက်ကနေလည်းပြန်ထွက်နေပါလိမ့်မယ် ငွေဝင်တာနဲ့ပြန်လှူလိုက်ရတာမျိုးပေးကမ်းရတာမျိုးပေါ့ငွေကိုစီစစ်သုံးပါ၊ငွေကြေးနဲ့ပတ်သက်ပီးအပြောင်းအလဲတွေရှိမယ်၊ငွေကြေးခက်ခဲနေသူဆိုရင်အထောက်ပံ့ပေးသူငွေချေးငှါးပေးသူရှိလာပါလိမ့်မယ်🦋",
            "🦋Pile-2🦋\r\n"
            + "သင်ဟာငွေကြေးကိုရင်းနှီးမြုပ်ဖို့စဉ်းစားနေသူဆိုရင်သတိထားပါငွေကြေးရင်းနှီးမြုပ်နှံထားဟာသင့်နဲ့မသင့်တော်ပါ၊လတ်တလောငွေအဝင်ပိတ်နေတတ်သည် ဘယ်အရာမှမဆုံးဖြတ်နိုင်ပဲဖြစ်နေတတ်သည်pile-2သမားတွေဟာ သူနာပြုအလုပ် ဖက်ရှင်အလုပ် အနုပညာအလုပ်တွေနဲ့အကျိုးပေးတတ်ပါတယ်🦋",
            "🦋Pile-3🦋\r\n"
            + "ငွေချေးထားတာငွေလက်လွန်ထားတာလေးတွေကြောင့်စိတ်ဆင်းရဲနေရတတ်တယ် ငွေကြေးဆုံးရှုံးရတတ်တယ်ငွေကြေးနဲ့ပတ်သက်ပီးပူပင်သောကများနေမယ် လတ်တလောငွေချေးငှါးလုပ်တာမျိုးရင်းနှီးမြုပ်နှံတာမျိုးမလုပ်ပါနဲ့ လက်ရှိအလုပ်နေလည်းရုတ်တရက်ထွက်လိုက်ရတာမျိုးလည်းဖြစ်တတ်လို့သတိထားပါ🦋"
        };
        pileArea.setText(pilePredictions[selectedPile-1]);
    }

    // ================= Page3 Logic =================
    private void predictChinese() {
        try{
            int year = Integer.parseInt(yearField.getText());
            String[] info = getChineseZodiacInfo(year);

            String animal = info[0];
            String emoji = info[1];
            String color = info[2];
            String numbers = info[3];

            chineseZodiacLabel.setText(animal+" "+emoji);

            StringBuilder sb = new StringBuilder();
            sb.append("မွေးနှစ်: ").append(year).append("\n");
            sb.append("နှစ်ဖွား: ").append(animal+" "+emoji).append("\n");
            sb.append("ကံကောင်းရောင်: ").append(color).append("\n");
            sb.append("ကံကောင်းဂဏန်း: ").append(numbers).append("\n\n");

            sb.append("ကံကောင်းနှစ်: ");
            for(int i=1;i<=5;i++){
                sb.append(year+i*12); if(i<5) sb.append(", ");
            }
            sb.append("\n");

            sb.append("ကံဆိုးနှစ်: ");
            for(int i=1;i<=5;i++){
                sb.append(year+i*6); if(i<5) sb.append(", ");
            }

            chineseArea.setText(sb.toString());

        } catch(Exception e){
            chineseArea.setText("မှန်ကန်သောနှစ်ကိုထည့်ပါ");
        }
    }

    private String[] getChineseZodiacInfo(int year){
        String[] animals = {"Rat","Ox","Tiger","Rabbit","Dragon","Snake","Horse","Goat","Monkey","Rooster","Dog","Pig"};
        String[] emojis = {"🐭","🐮","🐯","🐰","🐉","🐍","🐎","🐐","🐒","🐓","🐕","🐷"};
        String[] colors = {"Blue","White","Orange","Pink","Gold","Purple","Red","Green","Yellow","White","Brown","Blue"};
        String[] numbers = {"2,3","1,4","3,8","3,4","1,6,7","2,8","2,7","2,9","4,9","5,7","3,9","2,5"};
        int idx = (year-4)%12; if(idx<0) idx+=12;
        return new String[]{animals[idx], emojis[idx], colors[idx], numbers[idx]};
    }

    private void initPredictions(){
        predictionMap.put("Love", new String[]{
            "အချစ်ရေး၊ မေတ္တာရေးမှာ အရှုံးပေးတတ်သူမျိုး မဟုတ်ပါဘူး။ သူတို့တွေဟာ အိမ်ထောင်ရေးမှာဆိုရင် ငယ်ငယ်တည်းက ချစ်လာတဲ့ ချစ်သူတွေကိုပဲ လက်ထပ်ဖို့အထိ တွေးကြတယ်။ သာမန်ထက် ထူးခြားတဲ့ အရည်အသွေးရှိတဲ့ လူတွေနဲ့ တွေ့ဆုံရတတ်တယ်။ စိတ်ခံစားမှုထက် ပိုပြီး လက်တွေ့ကျတယ်။ ဖြူစင်သန့်ရှင်းတဲ့ အလှတရားကို နှစ်သက်ကြတယ်။ အချိန်အတော်ကြာ ဘယ်သူ့ကိုမှ မချစ်ဘဲ တစ်ယောက်တည်း နေနိုင်သလို ဘယ်သူနဲ့မှလဲ အပေါင်းအသင်းမလုပ်ဘဲလည်း နေနိုင်ပါတယ်။ အချစ်ရေးမှာ သစ္စာရှိသူတွေဖြစ်ပြီး သူတို့ရဲ့ ဘဝလက်တွဲဖော်ကိုလည်း ချစ်ခြင်းမေတ္တာတွေနဲ့ပဲ လွှမ်းမိုးထားလေ့ရှိပါတယ်",
            "အချစ်ရေးမှာ အထိခိုက် မခံနိုင်လောက်အောင် နူးညံလွန်းပါတယ်။ သူတို့က သူတို့ရဲ့ ဘဝလက်တွဲဖော်နဲ့ စိတ်ပိုင်းဆိုင်ရာ ဆက်နွယ်မှုရှိတယ်လို့ ယုံကြည်ကြတယ်။ စိတ်အပြောင်းအလဲမြန်တဲ့ သူတွေဖြစ်တဲ့အတွက် ကိုယ်ကစိတ်တည်ငြိမ်ပြီး သူတို့အပေါ် သည်းခံနိုင်ဖို့ လိုအပ်ပါတယ်။ကာမဂုဏ်ကို နှစ်ခြိုက်ပျော်မွေ့တတ်ပေမဲ့ သူတို့ရဲ့ ဘဝလက်တွဲဖော်ကိုတော့ ဆန္ဒကို ရှေ့တန်းတင် ရွေးချယ်လေ့ မရှိပါဘူး။ တကယ့် ချစ်ခြင်းမေတ္တာကိုသာ ဦးစားပေးလေ့ ရှိကြပါတယ်။ သူတို့အပေါ် အကောင်းဆုံး နားလည်မှုပေးနိုင်တဲ့ ဘဝလက်တွဲဖော်ကိုပဲ အိမ်ထောင်ဖက်အဖြစ် ရွေးချယ်တတ်ကြတယ်။ နှလုံးသားရဲ့ စေညွှန်ရာအတိုင်း လုပ်ဆောင်တတ်ကြပါတယ်",
            "လူတွေမသိနိုင်တဲ့ သမားရိုးကျမဟုတ်တဲ့ ထူးဆန်းတဲ့အရာတွေကို ပိုင်ဆိုင်ထားတတ်ကြတယ်။ သူတို့ဟာ စိတ်ကူးယဉ်ဆန်ဆန် မချစ်တတ်ကြပါဘူး။။တချို့သော သူတွေဟာ သစ္စာရှိကြပြီး သူတို့ရဲ့ ဘဝလက်တွဲဖော်ကို သူတို့ အပေါ် အနိုင်ယူခွင့် လွှမ်းမိုးခွင့် ပေးထားတတ်ကြပါတယ်။ လက်တွဲဖော်အပေါ်မှာ စိတ်နှစ်မြှုပ်လိုက်ပြီဆိုရင် တခြားသူများကို လုံးဝစိတ်ဝင်စားခြင်း မရှိတော့ပါဘူး။ သူတို့တွေဟာ စိတ်ဒေါသထွက်လွယ်တဲ့ အတွက်ကြောင့် အချစ်ရေးမှာ အဆုံးသတ်မလှတတ်ကြပါဘူး။ အချစ်တစ်ခုကို တည်မြဲဖို့ တည်ဆောက်တဲ့အခါ ကံမကောင်းတတ်တာကြောင့် အထူးဂရုစိုက်ဖို့ လိုအပ်ပါတယ်",
            "ပြီးပြည့်စုံတဲ့ လက်တွဲဖော်ကိုပဲ လိုချင်တဲ့အတွက် ရွေးချယ်လွန်းလို့ သူတို့ကို လူတွေက လူရှုပ်လူပွေလို့ ထင်တက်ကြတယ်။ သူတို့တွေဟာ စိတ်အပြောင်းအလဲ အလွန်မြန်တဲ့သူတွေ ဖြစ်တဲ့အတွက် သူတို့တွေရဲ့ ပြောင်းလဲမှု အနောက်ကိုလည်း အကောင်းမွန်ဆုံး လိုက်တတ်ကြတယ်။ သူတို့ရဲ့ လက်တွဲဖော်အပေါ်မှာလည်း ငြီးငွေ့လွယ်ကြတယ်။ ဒါပေမဲ့လည်း သူတို့ဟာ ချစ်တတ်ဖို့ကို အမြဲ ကြိုးစားနေသူတွေလည်း ဖြစ်ပါတယ်။ အချစ်ရေးမှာ ဆန္ဒကို ဦးစားပေးတတ်ပါတယ်။ စိတ်အပြောင်းအလဲမြန်တဲ့ သူတွေဖြစ်တဲ့အတွက် စိတ်တည်ငြိမ်ပြီး သူတို့အပေါ် သည်းခံနိုင်ဖို့ လိုအပ်ပါတယ်"
        });
        predictionMap.put("Career", new String[]{
            "ဒီကာလအတွင်း အလုပ်အကိုင်ပိုင်းမှာ တဖြည်းဖြည်း တိုးတက်မှုတွေ မြင်တွေ့ရနိုင်ပါတယ်။ တာဝန်ယူမှု မြင့်လာခြင်း၊ ကိုယ်ပိုင်အရည်အချင်းကို အထက်လူကြီးများက သတိထားမြင်လာနိုင်တဲ့ ကာလဖြစ်ပါတယ်။ စိတ်ရှည်ပြီး စီမံကိန်းအလိုက် လုပ်ကိုင်နိုင်ပါက အောင်မြင်မှုကောင်းများ ရရှိနိုင်ပါသည်",
            "ရာထူးတိုးတက်မှု၊ လစာတိုးမြှင့်မှုဆိုင်ရာ အခွင့်အရေးတွေ ပေါ်ပေါက်လာနိုင်ပါတယ်။ မိမိရဲ့ အလုပ်ကျွမ်းကျင်မှု၊ တာဝန်ခံမှုကို ပိုမိုပြသနိုင်ပါက အခွင့်အရေးကောင်းကို ဖမ်းဆီးနိုင်ပါလိမ့်မယ်",
            "အလုပ်ပြောင်းဖို့ စဉ်းစားနေသူများအတွက် ဒီကာလက အချိန်သင့်တော်တဲ့ ကာလဖြစ်နိုင်ပါတယ်။ သို့သော် အလျင်အမြန် ဆုံးဖြတ်ခြင်း မလုပ်ဘဲ အကျိုးအမြတ်၊ အနာဂတ်အလားအလာကို သေချာစဉ်းစားပြီးမှ ဆုံးဖြတ်သင့်ပါသည်",
            "ကိုယ်ပိုင်လုပ်ငန်းလုပ်ကိုင်သူများအတွက် ဖောက်သည်အသစ်များ ရရှိလာနိုင်ပြီး လုပ်ငန်းတိုးချဲ့ဖို့ အခွင့်အရေးတွေ မြင်တွေ့ရနိုင်ပါတယ်။ ငွေကြေးစီမံခန့်ခွဲမှုကို သေချာလုပ်ပါက ရေရှည်အတွက် အကျိုးရှိပါသည်"
        });
        predictionMap.put("Health", new String[]{
            "နှလုံးရောဂါ၊ ရင်ကျပ်တဲ့ရောဂါ၊ မျက်စိမွဲတဲ့ရောဂါ တွေ ဖြစ်လေ့ရှိတယ်။\r\n"
            + "\r\n"
            + "\r\n"
            + "ဂဏန်းဗေဒင် ပညာအရစားရမယ့် ဓာတ်စာတွေကတော့ စပျစ်သီး၊ သံပုရာသီး၊ ရှောက်သီး၊ လိမ္မော်သီး၊\r\n"
            + "ကျွှဲကောသီး၊ ပေါင်မုန့်၊ ဆန်ပြုတ်၊ ပျားရည်တွေ ဖြစ်တယ်",
            "အကြောနဲ့ပတ်သက်တဲ့ ရောဂါ၊ အာရုံကြောနဲ့ ပတ်သက်တဲ့ရောဂါ၊ အရေပြားနဲ့အဖုအပိမ့်တွေပေါက်တက်တဲ့ရောဂါ၊အသားနာကျင်ကိုက်ခဲတဲ့ ရောဂါတွေ ဖြစ်တက်တယ်။\r\n"
            + "\r\n"
            + "ဂဏန်းဗေဒင် ပညာအရစားရမယ့် ဓာတ်စာတွေကတော့\r\n"
            + "\r\n"
            + "စတော်ဘယ်ရီသီး၊ ဆီးဖြူသီး၊ နာနတ်သီး၊ ဗာဒံစေ့၊ ကညွတ်ရွက်၊ ပေါင်မုန့် စတဲ့ဟာတွေဖြစ်တယ်",
            "အကြောနဲ့ပတ်သက်တဲ့ ရောဂါ၊ အာရုံကြောနဲ့ ပတ်သက်တဲ့ရောဂါ၊ အရေပြားနဲ့အဖုအပိမ့်တွေပေါက်တက်တဲ့ရောဂါ၊အသားနာကျင်ကိုက်ခဲတဲ့ ရောဂါတွေ ဖြစ်တက်တယ်။\r\n"
            + "\r\n"
            + "ဂဏန်းဗေဒင် ပညာအရစားရမယ့် ဓာတ်စာတွေကတော့\r\n"
            + "\r\n"
            + "စတော်ဘယ်ရီသီး၊ ဆီးဖြူသီး၊ နာနတ်သီး၊ ဗာဒံစေ့၊ ကညွတ်ရွက်၊ ပေါင်မုန့် စတဲ့ဟာတွေဖြစ်တယ်",
            "စိတ္တဇဆန်ဆန် ရောဂါဖြစ်တယ်တယ်။ ဆီးအိမ်၊ကျောက်ကပ်စတဲ့ ရောဂါတွေဖြစ်တက်တယ်။ သူတို့ကိုရောဂါဖြစ်လာရင် ဓာတုဗေဒနည်းနဲ့ ဖော်စပ်ထားတဲ့ ဆေးတွေက ပိုပြီးသင့်တော်တယ်။ စိတ်ညှိ့ပြီးကုတဲ့ ဆရာတွေ၊ အိပ်မွေ့ချပြီးကုတဲ့ ဆရာတွေနဲ့ ကုသသင့်တယ်။\r\n"
            + "\r\n"
            + "အကောင်းဆုံးဓာတ်စာဟာ စိတ် အားမငယ်အောင် အားပေးတဲ့ မိတ်တွေပဲ"
        });
        predictionMap.put("Fortune", new String[]{
            "ဒီကာလအတွင်း ကံကောင်းမှုအခြေအနေ တဖြည်းဖြည်း တိုးတက်လာနိုင်ပါတယ်။ မျှော်လင့်မထားတဲ့ အခွင့်အရေးများ၊ ကူညီထောက်ပံ့သူများ ပေါ်ပေါက်လာနိုင်ပြီး ကြိုးစားမှုနဲ့ ကံကြမ္မာ ပေါင်းစပ်သွားတဲ့ ကာလဖြစ်ပါတယ်",
            "ဝင်ငွေအခွင့်အလမ်းအသစ်များ ကြုံတွေ့လာနိုင်ပြီး အပိုဝင်ငွေ ရရှိနိုင်တဲ့ ကာလဖြစ်ပါတယ်။ သို့သော် ဝင်သလောက် ထွက်လွယ်သော အခြေအနေပါရှိနိုင်လို့ သုံးစွဲမှုကို စီမံခန့်ခွဲသင့်ပါသည်",
            "မိမိမမျှော်လင့်ထားတဲ့ နေရာကနေ သတင်းကောင်းတွေ ကြားရနိုင်ပါတယ်။ လူမှုဆက်ဆံရေးကံကောင်းပြီး မိတ်ဆွေ၊ မိသားစုများထံမှ အထောက်အပံ့ရရှိနိုင်တဲ့ ကာလဖြစ်ပါတယ်",
            "မနက်ပိုင်းမှာ စိတ်ငြိမ်အောင်ထားခြင်း၊ ကောင်းသောအလုပ်များ ပြုလုပ်ခြင်းက ကံကောင်းမှုကို ပိုမို ဆွဲဆောင်နိုင်ပါတယ်။ အပြုသဘောဆောင်တဲ့ စိတ်နေစိတ်ထားက Fortune ကို ပိုမိုကောင်းမွန်စေပါသည်"
        });
        predictionMap.put("Education", new String[]{
            "ဒီကာလအတွင်း သင်ကြားရေး၊ စာပေဗဟုသုတနဲ့ ပတ်သက်တဲ့ ကံကြမ္မာကောင်းများ ရရှိလာနိုင်ပါတယ်။ စာဖတ်ခြင်း၊ သင်တန်းတက်ရောက်ခြင်းများမှာ အာရုံစူးစိုက်မှု မြင့်မားလာပြီး မိမိကြိုးစားသမျှ အကျိုးအမြတ် ပြန်ရရှိနိုင်ပါသည်။ မိဘ၊ ဆရာဆရာမများရဲ့ အထောက်အပံ့လည်း ရရှိလွယ်ကူတဲ့ ကာလဖြစ်ပါတယ်",
            "စာမေးပွဲဖြေဆိုရမယ့်သူများအတွက် စိတ်ဖိစီးမှု အနည်းငယ်ရှိနိုင်ပေမယ့် စာကြိုးစားမှု မလျော့ပါက မျှော်မှန်းထားသလို ရလဒ်ကောင်း ရရှိနိုင်ပါသည်။ အချိန်စီမံခန့်ခွဲမှုကို သေချာလုပ်ပါက အောင်မြင်မှု ပိုမိုမြင့်မားလာနိုင်ပါသည်",
            "ဒီကာလမှာ ကိုယ်တိုင် စိတ်ဝင်စားတဲ့ ဘာသာရပ်ကို ရွေးချယ်နိုင်တဲ့ အခွင့်အရေးကောင်းတွေ ပေါ်ပေါက်လာနိုင်ပါတယ်။ သိပ္ပံ၊ နည်းပညာ၊ စီးပွားရေး၊ ဘာသာစကားဆိုင်ရာ ပညာရပ်များမှာ အထူးကောင်းမွန်နိုင်ပြီး ရေရှည်အတွက် အကျိုးရှိတဲ့ ရွေးချယ်မှု ဖြစ်လာနိုင်ပါသည်",
            "ဒီကာလအတွင်း ပညာရေးပိုင်းမှာ အာရုံစူးစိုက်မှု ပိုမိုကောင်းမွန်လာပြီး သင်ယူလိုစိတ် တိုးတက်လာနိုင်ပါတယ်။ စာသင်ကြားမှု၊ သင်တန်းများမှာ အခက်အခဲအနည်းငယ် ရှိနိုင်ပေမယ့် ကြိုးစားမှု မလျော့ပါက ရလဒ်ကောင်းများ ရရှိနိုင်ပါသည်"
        });
    }

    private String getLuckyColor(String zodiac){
        switch(zodiac){
            case "Aries": return "Red"; case "Taurus": return "Green"; case "Gemini": return "Yellow"; case "Cancer": return "White";
            case "Leo": return "Gold"; case "Virgo": return "Green"; case "Libra": return "Pink"; case "Scorpio": return "Purple";
            case "Sagittarius": return "Orange"; case "Capricorn": return "Brown"; case "Aquarius": return "Blue"; case "Pisces": return "Violet";
            default: return "-";
        }
    }

    private String getLuckyNumber(String zodiac){
        switch(zodiac){
            case "Aries": return "1,9"; case "Taurus": return "2,6"; case "Gemini": return "3,5"; case "Cancer": return "2,7";
            case "Leo": return "1,8"; case "Virgo": return "5,6"; case "Libra": return "6,9"; case "Scorpio": return "4,8";
            case "Sagittarius": return "3,9"; case "Capricorn": return "4,7"; case "Aquarius": return "4,11"; case "Pisces": return "3,7";
            default: return "-";
        }
    }

    private void clearPage1(){ dobField.setText(""); zodiacField.setText(""); zodiacEmoji.setText(""); luckyColor.setText("-"); luckyNumber.setText("-"); previewArea.setText(""); page2Zodiac.setText("Zodiac: "); page2Emoji.setText(""); }
    private void clearPile(){ selectedPile=0; pileArea.setText(""); p1.setBorder(null); p2.setBorder(null); p3.setBorder(null); }
    private void clearChinese(){ yearField.setText(""); chineseZodiacLabel.setText(""); chineseArea.setText(""); }

    private JButton pileBtn(String path,int p){
        Image img; try{ img = ImageIO.read(getClass().getClassLoader().getResource(path)); } catch(Exception e){ img=new BufferedImage(90,120,BufferedImage.TYPE_INT_ARGB); }
        JButton b = new JButton(new ImageIcon(img.getScaledInstance(90,120,Image.SCALE_SMOOTH)));
        b.setContentAreaFilled(false); b.setBorder(BorderFactory.createEmptyBorder());
        b.addActionListener(e -> { selectedPile=p; p1.setBorder(null); p2.setBorder(null); p3.setBorder(null); b.setBorder(BorderFactory.createLineBorder(Color.MAGENTA,3)); });
        return b;
    }

    private void initZodiacEmojis(){ zodiacEmojis.put("Aries","♈️"); zodiacEmojis.put("Taurus","♉️"); zodiacEmojis.put("Gemini","♊️"); zodiacEmojis.put("Cancer","♋️"); zodiacEmojis.put("Leo","♌️"); zodiacEmojis.put("Virgo","♍️"); zodiacEmojis.put("Libra","♎️"); zodiacEmojis.put("Scorpio","♏️"); zodiacEmojis.put("Sagittarius","♐️"); zodiacEmojis.put("Capricorn","♑️"); zodiacEmojis.put("Aquarius","♒️"); zodiacEmojis.put("Pisces","♓️"); }
    private void initChineseEmojis(){ chineseEmojis.put("Rat","🐀"); chineseEmojis.put("Ox","🐂"); chineseEmojis.put("Tiger","🐅"); chineseEmojis.put("Rabbit","🐇"); chineseEmojis.put("Dragon","🐉"); chineseEmojis.put("Snake","🐍"); chineseEmojis.put("Horse","🐎"); chineseEmojis.put("Goat","🐐"); chineseEmojis.put("Monkey","🐒"); chineseEmojis.put("Rooster","🐓"); chineseEmojis.put("Dog","🐕"); chineseEmojis.put("Pig","🐖"); }

    private String zodiac(int m,int d){
        if((m==3&&d>=21)||(m==4&&d<=19)) return "Aries";
        if((m==4&&d>=20)||(m==5&&d<=20)) return "Taurus";
        if((m==5&&d>=21)||(m==6&&d<=20)) return "Gemini";
        if((m==6&&d>=21)||(m==7&&d<=22)) return "Cancer";
        if((m==7&&d>=23)||(m==8&&d<=22)) return "Leo";
        if((m==8&&d>=23)||(m==9&&d<=22)) return "Virgo";
        if((m==9&&d>=23)||(m==10&&d<=22)) return "Libra";
        if((m==10&&d>=23)||(m==11&&d<=21)) return "Scorpio";
        if((m==11&&d>=22)||(m==12&&d<=21)) return "Sagittarius";
        if((m==12&&d>=22)||(m==1&&d<=19)) return "Capricorn";
        if((m==1&&d>=20)||(m==2&&d<=18)) return "Aquarius";
        return "Pisces";
    }

    public static void main(String[] args){ new ClientGUI(); }
}
