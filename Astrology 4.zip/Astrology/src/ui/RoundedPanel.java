package ui;

import javax.swing.*;
import java.awt.*;

public class RoundedPanel extends JPanel {

    private final Color bg;
    private int radius = 25;

    public RoundedPanel(Color bg) {
        this.bg = bg;
        setOpaque(false);
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(
            RenderingHints.KEY_ANTIALIASING,
            RenderingHints.VALUE_ANTIALIAS_ON
        );
        g2.setColor(bg);
        g2.fillRoundRect(0,0,getWidth(),getHeight(),radius,radius);
        super.paintComponent(g);
    }
}