package server;

import common.AstrologyService;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class ServerMain {
    public static void main(String[] args) throws Exception {
        AstrologyService service = new AstrologyServiceImpl();
        Registry reg = LocateRegistry.createRegistry(1099);
        reg.rebind("AstrologyService", service);
        System.out.println("Astrology RMI Server started...");
    }
}