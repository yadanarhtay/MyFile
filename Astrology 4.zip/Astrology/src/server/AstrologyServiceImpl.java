package server;

import common.AstrologyService;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.Random;

public class AstrologyServiceImpl extends UnicastRemoteObject implements AstrologyService {

    private Random random = new Random();

    protected AstrologyServiceImpl() throws RemoteException { super(); }

    @Override
    public String getPrediction(String zodiac, String type, int pile) throws RemoteException {
        String[] arr = {
                "Pile shows growth. Love: ❤️, Career: 💼, Health: 🥗",
                "Pile brings new beginnings. Love: 💖, Career: 📈, Health: 💪",
                "Pile is full of energy. Love: 🔥, Career: 💻, Health: 🧘"
        };
        return arr[random.nextInt(arr.length)];
    }

    @Override
    public String getLuckyColor(String zodiac) throws RemoteException {
        String[] colors = {"Red","Blue","Green","Yellow","Purple","Orange"};
        return colors[random.nextInt(colors.length)];
    }

    @Override
    public int getLuckyNumber(String zodiac) throws RemoteException {
        return random.nextInt(9)+1;
    }

    @Override
    public String getPreview(String zodiac, String type, String timeframe) throws RemoteException {
        return type + " " + timeframe + " preview for " + zodiac;
    }

    @Override
    public String getMyanmarPrediction(String myanmarDob) throws RemoteException {
        // Dummy implementation: you can add Mahabot, Raza, Adhipati logic here
        return "Myanmar Astrology Result for " + myanmarDob + "\n" +
                "Mahabot: 5\nRaza: 3\nAdhipati: Sun\nAthun: 2\nLucky number: 7\nLucky color: Gold";
    }

    @Override
    public String getChineseZodiac(int year) throws RemoteException {
        String[] animals = {
                "Rat","Ox","Tiger","Rabbit","Dragon","Snake","Horse","Goat","Monkey","Rooster","Dog","Pig"
        };
        int idx = (year - 1900) % 12;
        return "Chinese Zodiac for year " + year + ": " + animals[idx] +
                "\nLucky color: Red\nLucky number: " + (idx+1);
    }
}